﻿
namespace DiningPhilosophers1
{
	/// <summary>
	/// A philosopher may be either Thinking or Eating
	/// </summary>
	public enum PhilosopherStatus { Thinking, Eating };
}
