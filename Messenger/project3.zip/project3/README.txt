The jpeg contains a sample run on my system.

The program runs on only one file, with all of the classes being on that file.

Keys generated of values other than a multiple of 8 will be rounded down to the nearest multiple of 8, 
this is because the random number generater used only works with bytes, so generating a more complex number, 
then shifting the bits off is almost pointless when all that would do is reduce the complexity of the keys generated for the same, 
if not more effort.